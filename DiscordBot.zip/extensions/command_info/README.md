adds a custom command_info field to each command with a provided raw data for an automatic help command. 
![](https://cdn.discordapp.com/attachments/676795541056651304/676985383715602432/unknown.png)  
![](https://cdn.discordapp.com/attachments/676795541056651304/676985446236160000/unknown.png)  
![](https://cdn.discordapp.com/attachments/676795541056651304/676984788845854720/unknown.png)  
