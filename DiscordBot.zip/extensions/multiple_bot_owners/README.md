**Do not forget that that gives Bot Owner status according to DBM( as in access to anything set as *Bot Owner Only* )**

Insert the desired owner's Discord ID, It **MUST** be the discord id, not the name of the user 
(Right click -> Copy ID on the users name with developer mode enabled) 
Once you click the + to add the id, you may close the extension and restart your bot. 

Failure to restart your bot will result in the the user to not have Bot Owner Only status

![Picture of interface](https://i.imgur.com/uvpmbKY.png)





